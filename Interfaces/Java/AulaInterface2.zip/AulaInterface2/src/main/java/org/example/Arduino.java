package org.example;

import java.util.List;

public class Arduino {

    private List<Sensor> sensorList;
    private Connection connection;


    public Arduino(List<Sensor> sensorList, Connection connection) {
        this.sensorList = sensorList;
        this.connection = connection;
    }

    public void run() {
        for (Sensor sensor : sensorList) {
            Data data = sensor.read();
            connection.send(data);
        }
    }
}
