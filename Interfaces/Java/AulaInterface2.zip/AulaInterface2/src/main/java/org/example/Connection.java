package org.example;

public interface Connection {

    void send(Data data);
}
