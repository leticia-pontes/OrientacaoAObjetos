package org.example;

public class ConstSensor implements Sensor {

    private float valor;
    private Unit unit;

    public ConstSensor(float valor, Unit unit) {
        this.valor = valor;
        this.unit = unit;
    }

    @Override
    public Data read() {
        return new Data(valor, unit);
    }
}
