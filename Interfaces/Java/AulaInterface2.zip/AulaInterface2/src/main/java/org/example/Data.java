package org.example;

import java.util.Objects;

public class Data {
    private float valor;
    private Unit unit;

    public Data(float valor, Unit unit) {
        this.valor = valor;
        this.unit = unit;
    }

    public float getValor() {
        return valor;
    }

    public Unit getUnit() {
        return unit;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Data data = (Data) o;
        return Float.compare(valor, data.valor) == 0 && unit == data.unit;
    }

    @Override
    public int hashCode() {
        return Objects.hash(valor, unit);
    }

    @Override
    public String toString() {
        return "Data{" +
                "valor=" + valor +
                ", unit=" + unit +
                '}';
    }
}
