package org.example;

public class FakeConnection implements Connection {

    @Override
    public void send(Data data) {
        System.err.println(data);
    }
}


