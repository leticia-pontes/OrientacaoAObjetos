package org.example;

import javax.swing.*;

public class HttpConnection implements Connection {

    private String host;
    private int port;

    public HttpConnection(String host, int port) {
        this.host = host;
        this.port = port;
    }

    @Override
    public void send(Data data) {
        JOptionPane.showMessageDialog(null, String.valueOf(data));
    }
}
