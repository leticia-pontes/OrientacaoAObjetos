package org.example;

import java.util.List;

public class Main {

    public static void main(String[] args) {
        Sensor bolado = new SensorBolado(List.of(
                new ConstSensor(24.5f, Unit.Celsius),
                new ConstSensor(26f, Unit.Celsius)
        ));
        Sensor dht22 = new ConstSensor(24f, Unit.Celsius);
        Connection connection = new FakeConnection();
        Arduino arduino = new Arduino(
                List.of(bolado),
                connection
        );
        arduino.run();
    }
}