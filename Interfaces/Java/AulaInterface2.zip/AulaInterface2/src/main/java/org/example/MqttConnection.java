package org.example;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class MqttConnection implements Connection {

    private String host;
    private int port;

    public MqttConnection(String host, int port) {
        this.host = host;
        this.port = port;
    }

    @Override
    public void send(Data data) {
        try (OutputStream outputStream = new FileOutputStream("saida.txt")) {
            outputStream.write(String.valueOf(data).getBytes());
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }
}
