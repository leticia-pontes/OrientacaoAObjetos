package org.example;

public interface Sensor {

    Data read();
}
