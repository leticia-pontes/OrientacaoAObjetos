package org.example;

import java.util.List;

public class SensorBolado implements Sensor {

    private List<Sensor> sensores;

    public SensorBolado(List<Sensor> sensores) {
        this.sensores = sensores;
    }

    @Override
    public Data read() {
        float media = 0;
        for (Sensor sensor : sensores) {
            Data data = sensor.read();
            media += data.getValor();
        }
        media /= sensores.size();
        return new Data(media, Unit.Celsius);
    }
}
