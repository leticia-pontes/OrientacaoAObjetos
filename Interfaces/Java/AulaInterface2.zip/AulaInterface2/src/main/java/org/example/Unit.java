package org.example;

public enum Unit {
    Celsius,
    Kelvin,
    Fahrenheit,
}
